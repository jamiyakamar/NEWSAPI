export default {
  API_KEY: process.env.API_KEY,
  mongoURI: process.env.MONGO_URI,
  BASE_URL: process.env.BASE_URL,
  secret: process.env.SECRET_KEY
};
