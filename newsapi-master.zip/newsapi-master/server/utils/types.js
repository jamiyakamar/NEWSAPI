const Categories = Object.freeze({
  Business: "business",
  Entertainment: "entertainment",
  General: "general",
  Health: "health",
  Science: "science",
  Sports: "sports",
  Technology: "technology",
  Topheadline: "topheadline"
});

export { Categories };
