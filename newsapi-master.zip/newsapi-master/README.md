# newsapi
MERN stack news aggregation site using extenal news JSON APIs

Sample News aggregator site based on newsapi.org API using node.js,express,mongodb and React (MERN stack).Created for simple demo purpose.

Functionalities : every half an hour news will get updated based on newsapi.org API.News will be displayed based on different categories.In future planning to add an option for registered user to see customized categories of news in the home page.

Registration and authentication functionalities has been added but there is no additonal features added for registered user.

Main packages used on nodejs side : jwt for authentication,jest for testing,mongoose for database access, ES6 based import is used with babel along with other packages.node based on cron is used for updating news on specific intervals.

create react app is used for react app. mlab is used to create mongo instance.

following code will be added later:


React testing part


React Server side rendering

working server url : https://glacial-hollows-38193.herokuapp.com/
