import React, { Component } from "react";

export default class Settings extends Component {
  render() {
    return (
      <div id="main">
        <div className="container">
          <div className="row">
            <h2>
              settings page.Need to work to show it on different categories of
              news to be shown on the home page
            </h2>
          </div>
          <div className="row" />
          <div className="row ">
            <div className="marginLeft40">
              <h2>Work In progress</h2>
            </div>
          </div>
        </div>
      </div>
    );
  }
}
